# Analiza zvoka v javi

Program za analiziranje zvoka v Javi.

## Dokumentacija

[link](http://www.javazoom.net/javalayer/docs/docs1.0/javazoom/jl/decoder/Decoder.html#getOutputFrequency%28%29)